<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold mb-4">Devedores</h1>

<?php echo $__env->make('partials.store-switcher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="bg-white rounded shadow p-4 mb-4 inline-block">
    <div class="text-sm text-gray-500">Total em atraso</div>
    <div class="text-2xl font-bold text-red-600"><?php echo e(number_format($totalOwed, 2, ',', '.')); ?></div>
</div>

<form method="GET" class="flex gap-2 mb-4">
    <input type="hidden" name="store_id" value="<?php echo e($storeId); ?>">
    <input name="q" value="<?php echo e(request('q')); ?>" placeholder="Nome, bloco, apartamento ou telefone" class="border rounded p-2 w-80">
    <button class="border rounded px-4 bg-white">Pesquisar</button>
</form>

<table class="w-full bg-white rounded shadow text-sm">
    <thead class="text-left border-b">
        <tr><th class="p-3">Cliente</th><th>Bloco / Apt.</th><th>Telefone</th><th>Períodos</th><th>Mais antigo</th><th class="text-right pr-3">Deve</th></tr>
    </thead>
    <tbody>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $debtors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <tr class="border-b">
            <td class="p-3"><?php echo e($d->name); ?></td>
            <td><?php echo e(trim($d->block.' '.$d->unit)); ?></td>
            <td><?php echo e($d->phone); ?></td>
            <td><?php echo e($d->n); ?></td>
            <td><?php echo e(\Carbon\Carbon::parse($d->oldest)->format('d/m/Y')); ?></td>
            <td class="text-right pr-3 font-semibold text-red-600"><?php echo e(number_format($d->owed, 2, ',', '.')); ?></td>
        </tr>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        <tr><td colspan="6" class="p-4 text-gray-500">Ninguém em atraso.</td></tr>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </tbody>
</table>

<div class="mt-4"><?php echo e($debtors->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PDV\resources\views/billing/debtors.blade.php ENDPATH**/ ?>