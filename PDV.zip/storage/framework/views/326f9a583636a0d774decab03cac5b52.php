<?php
    $labels = [
        'catalog' => 'Produtos', 'stock' => 'Estoque', 'sales' => 'Vendas',
        'purchases' => 'Compras e fornecedores', 'users' => 'Utilizadores e perfis',
    ];
?>

<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold mb-1"><?php echo e($role->exists ? 'Editar perfil' : 'Novo perfil'); ?></h1>
<p class="text-gray-500 mb-4">Loja: <?php echo e($store?->name); ?></p>

<form method="POST"
      action="<?php echo e($role->exists ? route('roles.update', $role) : route('roles.store')); ?>"
      class="bg-white p-6 rounded shadow max-w-2xl space-y-5">
    <?php echo csrf_field(); ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($role->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <input type="hidden" name="store_id" value="<?php echo e($storeId); ?>">

    <input name="name" value="<?php echo e(old('name', $role->name)); ?>" placeholder="Nome do perfil"
           class="w-full border rounded p-2">

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $perms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <fieldset class="border rounded p-3">
            <legend class="px-2 font-semibold flex items-center gap-3">
                <?php echo e($labels[$group] ?? $group); ?>

                <button type="button" class="text-xs text-blue-600 font-normal"
                        onclick="this.closest('fieldset').querySelectorAll('input[type=checkbox]:not(:disabled)').forEach(c => c.checked = !c.checked)">
                    marcar/desmarcar
                </button>
            </legend>
            <div class="grid sm:grid-cols-2 gap-2">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $perms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <?php $can = in_array($p->id, $allowed); ?>
                    <label class="flex items-center gap-2 text-sm <?php echo e($can ? '' : 'opacity-50'); ?>">
                        <input type="checkbox" name="permissions[]" value="<?php echo e($p->id); ?>"
                               <?php if(in_array($p->id, old('permissions', $selected))): echo 'checked'; endif; ?>
                               <?php if(! $can): echo 'disabled'; endif; ?>>
                        <?php echo e($p->label); ?>

                    </label>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
        </fieldset>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

    <div class="flex gap-3">
        <button class="bg-blue-600 text-white rounded px-4 py-2">Guardar</button>
        <a href="<?php echo e(route('roles.index', ['store_id' => $storeId])); ?>" class="px-4 py-2 text-gray-600">Cancelar</a>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PDV\resources\views/roles/form.blade.php ENDPATH**/ ?>