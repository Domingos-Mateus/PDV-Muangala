<!DOCTYPE html>
<html lang="pt">

<head>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.14.5/dist/sweetalert2.all.min.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title ?? 'PDV'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>

<body class="bg-gray-100 text-gray-800">
    <nav class="bg-white shadow px-6 py-3 flex items-center justify-between">
        <div class="flex items-center gap-6">
            <a href="<?php echo e(route('dashboard')); ?>" class="font-bold">PDV</a>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sales.create')): ?>
                <a href="<?php echo e(route('pdv.index')); ?>">Vender</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sales.view')): ?>
                <a href="<?php echo e(route('sales.index')); ?>">Vendas</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('products.view')): ?>
                <a href="<?php echo e(route('products.index')); ?>">Produtos</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cash.operate')): ?>
                <a href="<?php echo e(route('cash.current')); ?>">Caixa</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cash.manage')): ?>
                <a href="<?php echo e(route('cash.sessions')); ?>">Turnos</a> <a href="<?php echo e(route('cash.registers.index')); ?>">Caixas</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('categories.manage')): ?>
                <a href="<?php echo e(route('categories.index')); ?>">Categorias</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stock.view')): ?>
                <a href="<?php echo e(route('stock.index')); ?>">Estoque</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchases.view')): ?>
                <a href="<?php echo e(route('purchases.index')); ?>">Compras</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('suppliers.manage')): ?>
                <a href="<?php echo e(route('suppliers.index')); ?>">Fornecedores</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('services.manage')): ?>
                <a href="<?php echo e(route('services.index')); ?>">Serviços</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customers.manage')): ?>
                <a href="<?php echo e(route('customers.index')); ?>">Clientes</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('services.manage')): ?>
                <a href="<?php echo e(route('subscriptions.index')); ?>">Contratos</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('billing.collect')): ?>
                <a href="<?php echo e(route('billing.collect')); ?>">Cobrar</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('billing.view')): ?>
                <a href="<?php echo e(route('billing.debtors')); ?>">Devedores</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('billing.view')): ?>
                <a href="<?php echo e(route('billing.report')); ?>">Cobranças</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('super-admin')): ?>
                <a href="<?php echo e(route('stores.index')); ?>">Lojas</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.manage')): ?>
                <a href="<?php echo e(route('roles.index')); ?>">Perfis</a>
                <a href="<?php echo e(route('users.index')); ?>">Utilizadores</a>
            <?php endif; ?>
        </div>
        <div class="flex items-center gap-4 text-sm">
            <span><?php echo e(auth()->user()->name); ?>

                <small class="text-gray-500">(<?php echo e(auth()->user()->store?->name ?? 'Todas as lojas'); ?>)</small>
            </span>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button class="text-red-600">Sair</button>
            </form>
        </div>
    </nav>

    <main class="p-6">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('ok')): ?>
            <div class="bg-green-100 text-green-800 p-3 rounded mb-4"><?php echo e(session('ok')); ?></div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php echo e($slot ?? ''); ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            document.addEventListener('submit', (e) => {
                const form = e.target;
                if (!form.dataset.confirm || form.dataset.confirmed) return;
                e.preventDefault();
                Swal.fire({
                    icon: 'warning',
                    title: form.dataset.confirm,
                    showCancelButton: true,
                    confirmButtonText: 'Sim, continuar',
                    cancelButtonText: 'Cancelar',
                    confirmButtonColor: '#2563eb',
                }).then((r) => {
                    if (r.isConfirmed) {
                        form.dataset.confirmed = '1';
                        form.submit();
                    }
                });
            });
            <?php if(session('ok')): ?>
                Swal.fire({
                    toast: true,
                    position: 'top-end',
                    icon: 'success',
                    title: <?php echo json_encode(session('ok'), 15, 512) ?>,
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                });
            <?php endif; ?>

            <?php if($errors->any()): ?>
                Swal.fire({
                    icon: 'error',
                    title: 'Não foi possível guardar',
                    html: <?php echo json_encode(collect($errors->all())->map(fn($m) => e($m))->implode('<br>'), 15, 512) ?>,
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#2563eb',
                });
            <?php endif; ?>
        });
    </script>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


    <script>
        // mantém a sessão viva enquanto a página estiver aberta
        setInterval(() => {
            fetch('<?php echo e(route('dashboard')); ?>', {
                method: 'HEAD',
                credentials: 'same-origin'
            });
        }, 10 * 60 * 1000);
    </script>
</body>

</html>
<?php /**PATH C:\laragon\www\PDV\resources\views/layouts/app.blade.php ENDPATH**/ ?>