<?php $fmt = fn ($n) => number_format((float) $n, 2, ',', '.'); ?>

<div class="grid lg:grid-cols-3 gap-4">
    <div class="lg:col-span-2 space-y-4">
        
        <div class="bg-white rounded shadow p-4 relative">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($customer): ?>
                <div class="flex items-center justify-between">
                    <div>
                        <div class="text-lg font-bold"><?php echo e($customer->name); ?></div>
                        <div class="text-sm text-gray-500"><?php echo e(trim($customer->block.' '.$customer->unit)); ?> <?php echo e($customer->phone ? '· '.$customer->phone : ''); ?></div>
                    </div>
                    <button type="button" wire:click="clear" class="text-blue-600 text-sm">Trocar cliente</button>
                </div>
            <?php else: ?>
                <input type="text" autofocus autocomplete="off" wire:model.live.debounce.250ms="search"
                       placeholder="Nome, bloco, apartamento ou telefone" class="w-full border rounded p-3 text-lg">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($results->isNotEmpty()): ?>
                    <div class="absolute left-4 right-4 mt-1 bg-white border rounded shadow z-10 divide-y">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <button type="button" wire:click="pick(<?php echo e($c->id); ?>)" class="w-full text-left p-3 hover:bg-gray-50">
                                <?php echo e($c->name); ?> <small class="text-gray-500"><?php echo e(trim($c->block.' '.$c->unit)); ?> <?php echo e($c->phone); ?></small>
                            </button>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                <?php elseif(mb_strlen(trim($search)) >= 2): ?>
                    <p class="text-sm text-gray-500 mt-2">Nenhum cliente encontrado.</p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($customer): ?>
            <div class="bg-white rounded shadow">
                <table class="w-full text-sm">
                    <thead class="text-left border-b">
                        <tr><th class="p-3 w-10"></th><th>Período</th><th>Estado</th><th class="text-right">Saldo</th><th class="w-36 text-right pr-3">A pagar</th></tr>
                    </thead>
                    <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $charges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php
                            $overdue = $c->due_date->lt(today());
                            $current = ! $overdue && $c->period_start->lte(today());
                            $on = ! empty($selected[$id]);
                        ?>
                        <tr class="border-b" <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'ch-'.e($id).''; ?>wire:key="ch-<?php echo e($id); ?>">
                            <td class="p-3"><input type="checkbox" wire:model.live="selected.<?php echo e($id); ?>"></td>
                            <td><?php echo e($c->description); ?></td>
                            <td>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($overdue): ?> <span class="text-red-600 font-semibold">Em atraso</span>
                                <?php elseif($current): ?> <span class="text-yellow-700">Mês actual</span>
                                <?php else: ?> <span class="text-gray-500">Adiantado</span> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                            <td class="text-right"><?php echo e($fmt($c->balance())); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($c->paid_amount > 0): ?> <small class="text-gray-500 block">de <?php echo e($fmt($c->amount)); ?></small><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></td>
                            <td class="text-right pr-3">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($on && $overdue): ?>
                                    <input type="text" inputmode="decimal" wire:model.live.debounce.400ms="amounts.<?php echo e($id); ?>" class="w-28 border rounded p-1 text-right">
                                <?php elseif($on): ?>
                                    <?php echo e($fmt($c->balance())); ?>

                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                        </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        <tr><td colspan="5" class="p-6 text-center text-gray-500">Este cliente não tem períodos por pagar. Se tiver contratos, usa «Pagar adiantado».</td></tr>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
                <div class="p-3 flex items-center justify-between text-sm border-t">
                    <span class="text-gray-500">Só a dívida em atraso pode ser paga em parcelas.</span>
                    <button type="button" wire:click="more" <?php if($ahead >= 12): echo 'disabled'; endif; ?> class="text-blue-600 disabled:opacity-40">+ Pagar adiantado (mais 1 período)</button>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    
    <div class="space-y-4">
        <div class="bg-white rounded shadow p-4 space-y-3">
            <div class="flex justify-between text-2xl font-bold"><span>Total</span><span><?php echo e($fmt($t['total'])); ?></span></div>
            <div class="text-sm text-gray-500"><?php echo e(count($alloc)); ?> período(s) seleccionado(s)</div>
        </div>

        <div class="bg-white rounded shadow p-4 space-y-3">
            <h2 class="font-semibold">Pagamento</h2>
            <label class="flex items-center justify-between text-sm gap-2">Cartão (TPA)
                <input type="text" inputmode="decimal" wire:model.live.debounce.300ms="card" class="w-32 border rounded p-1 text-right"></label>
            <label class="flex items-center justify-between text-sm gap-2">Transferência
                <input type="text" inputmode="decimal" wire:model.live.debounce.300ms="transfer" class="w-32 border rounded p-1 text-right"></label>
            <label class="flex items-center justify-between text-sm gap-2">Dinheiro entregue
                <input type="text" inputmode="decimal" wire:model.live.debounce.300ms="cash" class="w-32 border rounded p-1 text-right"></label>

            <button type="button" wire:click="exact" class="text-sm text-blue-600">Dinheiro exacto (<?php echo e($fmt(max($t['cashDue'], 0))); ?>)</button>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($t['over']): ?>
                <p class="text-sm text-red-600">Cartão e transferência passam do total.</p>
            <?php elseif($t['cashDue'] > 0 && $t['missing'] > 0 && $t['total'] > 0): ?>
                <p class="text-sm text-red-600">Faltam <?php echo e($fmt($t['missing'])); ?></p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <div class="flex justify-between text-lg font-bold <?php echo e($t['change'] > 0 ? 'text-green-700' : ''); ?>"><span>Troco</span><span><?php echo e($fmt($t['change'])); ?></span></div>

            <button type="button" wire:click="checkout" wire:loading.attr="disabled" wire:target="checkout" <?php if($t['blocked']): echo 'disabled'; endif; ?>
                    class="w-full bg-green-600 text-white rounded p-3 text-lg disabled:opacity-40">Receber pagamento</button>
        </div>

        <div class="bg-white rounded shadow p-4 text-sm">
            <h2 class="font-semibold mb-2">Os meus últimos recibos</h2>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="flex items-center justify-between py-1 border-b <?php echo e($r->status === 'cancelled' ? 'text-gray-400 line-through' : ''); ?>">
                    <span><?php echo e($r->number); ?> <small class="text-gray-500"><?php echo e($r->customer?->name); ?></small></span>
                    <span class="flex items-center gap-3"><?php echo e($fmt($r->total)); ?>

                        <button type="button" class="text-blue-600" onclick="window.pdvPrint('<?php echo e(route('billing.receipt', [$r->id, 'auto' => 1])); ?>')">Reimprimir</button>
                    </span>
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <p class="text-gray-500">Ainda não recebeste nada.</p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

        <?php
        $__scriptKey = '4271593779-0';
        ob_start();
    ?>
    <script>
        window.pdvPrint = (url) => {
            document.getElementById('receipt-frame')?.remove();
            const f = document.createElement('iframe');
            f.id = 'receipt-frame';
            f.style.cssText = 'position:fixed;width:0;height:0;border:0;right:0;bottom:0';
            f.src = url;
            document.body.appendChild(f);
        };

        $wire.on('collect-notify', (e) => {
            const d = Array.isArray(e) ? e[0] : e;
            Swal.fire({ icon: 'error', title: d.title, text: d.text, confirmButtonColor: '#2563eb' });
        });

        $wire.on('collect-done', (e) => {
            const d = Array.isArray(e) ? e[0] : e;
            Swal.fire({
                icon: 'success', title: 'Recibo ' + d.number,
                html: '<div style="font-size:14px;color:#6b7280">Total ' + d.total + '</div>'
                    + '<div style="font-size:28px;font-weight:700;margin-top:6px">Troco: ' + d.change + '</div>',
                showCancelButton: true, confirmButtonText: 'Imprimir recibo', cancelButtonText: 'Fechar',
                confirmButtonColor: '#16a34a', allowOutsideClick: false,
            }).then((r) => { if (r.isConfirmed) window.pdvPrint(d.url); });
        });
    </script>
        <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
</div>
<?php /**PATH C:\laragon\www\PDV\resources\views/livewire/collect.blade.php ENDPATH**/ ?>